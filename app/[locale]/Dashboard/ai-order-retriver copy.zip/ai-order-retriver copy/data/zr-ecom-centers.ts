[
    {
        "IDWilaya": 1,
        "NomBureau": "ADRAR",
        "Reclamation": "06 61 11 00 53"
    },
    {
        "IDWilaya": 2,
        "NomBureau": "CHLEF",
        "Reclamation": "0770 99 46 75"
    },
    {
        "IDWilaya": 2,
        "NomBureau": "TENES",
        "Reclamation": "0770 99 45 62 "
    },
    {
        "IDWilaya": 3,
        "NomBureau": "LAGHOUATE",
        "Reclamation": "07 70 73 56 83 "
    },
    {
        "IDWilaya": 4,
        "NomBureau": "OUM EL BOUGHI - AIN EL BEIDA ",
        "Reclamation": "0660 73 74 74"
    },
    {
        "IDWilaya": 4,
        "NomBureau": "OUM EL BOUGHI - VILLE LIVREUR",
        "Reclamation": "06 72 96 10 16"
    },
    {
        "IDWilaya": 5,
        "NomBureau": "BATNA",
        "Reclamation": "07 70 55 52 45 "
    },
    {
        "IDWilaya": 6,
        "NomBureau": "BEJAIA",
        "Reclamation": "07 70 60 34 02 "
    },
    {
        "IDWilaya": 6,
        "NomBureau": "AKBOU",
        "Reclamation": "07 70 10 45 78"
    },
    {
        "IDWilaya": 7,
        "NomBureau": "BISKRA",
        "Reclamation": "06 71 99 66 54 "
    },
    {
        "IDWilaya": 8,
        "NomBureau": "BECHAR",
        "Reclamation": "06 73 89 23 26"
    },
    {
        "IDWilaya": 9,
        "NomBureau": "BLIDA",
        "Reclamation": "07 70 77 21 11 / 0562269817"
    },
    {
        "IDWilaya": 9,
        "NomBureau": "BLIDA BOUGARA",
        "Reclamation": "07 70 77 21 11 / 0562269817"
    },
    {
        "IDWilaya": 9,
        "NomBureau": "BLIDA MOUZAIA",
        "Reclamation": "07 70 77 21 11 / 0562269817"
    },
    {
        "IDWilaya": 10,
        "NomBureau": "BOUIRA",
        "Reclamation": "07 70 38 18 12 "
    },
    {
        "IDWilaya": 11,
        "NomBureau": "TAMANRASSET",
        "Reclamation": "07 70 99 46 06"
    },
    {
        "IDWilaya": 12,
        "NomBureau": "TEBESSA",
        "Reclamation": "07 75 64 75 14 "
    },
    {
        "IDWilaya": 13,
        "NomBureau": "TLEMCEN",
        "Reclamation": "07 70 39 69 54 "
    },
    {
        "IDWilaya": 14,
        "NomBureau": "TIARET",
        "Reclamation": "0770797231"
    },
    {
        "IDWilaya": 15,
        "NomBureau": "TIZI OUZOU",
        "Reclamation": "07 70 18 06 02 "
    },
    {
        "IDWilaya": 16,
        "NomBureau": "ALGER - BIRKHADEM",
        "Reclamation": "07 70 56 66 68 /07 70 78 06 10"
    },
    {
        "IDWilaya": 16,
        "NomBureau": "ALGER - LIDOU ",
        "Reclamation": "07 70 37 67 30 "
    },
    {
        "IDWilaya": 16,
        "NomBureau": "ALGER - OULED FAYET ",
        "Reclamation": "0770 07 22 26 "
    },
    {
        "IDWilaya": 16,
        "NomBureau": "HUB REGHAIA",
        "Reclamation": "07 70 19 72 98"
    },
    {
        "IDWilaya": 16,
        "NomBureau": "ALGER - BIRTOUTA ",
        "Reclamation": "07 76 06 26 54"
    },
    {
        "IDWilaya": 16,
        "NomBureau": " ALGER-ELJOMHORIA",
        "Reclamation": "0770 86 81 60"
    },
    {
        "IDWilaya": 16,
        "NomBureau": "ALGER-BARAKI",
        "Reclamation": "0770 18 38 69"
    },
    {
        "IDWilaya": 17,
        "NomBureau": "DJELFA",
        "Reclamation": "07 70 45 16 00"
    },
    {
        "IDWilaya": 18,
        "NomBureau": "JIJEL",
        "Reclamation": "06 57 25 44 90"
    },
    {
        "IDWilaya": 18,
        "NomBureau": "JIJEL-TAHER",
        "Reclamation": "0770367618"
    },
    {
        "IDWilaya": 19,
        "NomBureau": "SÉTIF ",
        "Reclamation": "05 49 66 41 74"
    },
    {
        "IDWilaya": 19,
        "NomBureau": "El EULMA",
        "Reclamation": "07 70 33 99 75"
    },
    {
        "IDWilaya": 20,
        "NomBureau": "SAIDA",
        "Reclamation": "0770 80 87 91"
    },
    {
        "IDWilaya": 21,
        "NomBureau": "SKIKDA",
        "Reclamation": "07 92 43 57 32"
    },
    {
        "IDWilaya": 22,
        "NomBureau": "SIDI BEL ABBES",
        "Reclamation": "07 73 98 12 87 "
    },
    {
        "IDWilaya": 23,
        "NomBureau": "ANNABA",
        "Reclamation": "07 96 36 96 89"
    },
    {
        "IDWilaya": 23,
        "NomBureau": "ANNABA  EL BOUNI",
        "Reclamation": "0796 36 96 89"
    },
    {
        "IDWilaya": 24,
        "NomBureau": "GUELMA",
        "Reclamation": "07 91 61 67 69 /07 70 96 22 21"
    },
    {
        "IDWilaya": 25,
        "NomBureau": "CONSTANTINE - ZOUAGHI",
        "Reclamation": "07 70 54 53 05 "
    },
    {
        "IDWilaya": 25,
        "NomBureau": "CONSTANTINE - NOUVELLE VILLE ",
        "Reclamation": "07 70 60 14 05 "
    },
    {
        "IDWilaya": 25,
        "NomBureau": "CONSTANTINE - BELLE VUE",
        "Reclamation": "07 70 60 14 05 "
    },
    {
        "IDWilaya": 26,
        "NomBureau": "MEDEA",
        "Reclamation": "07 79 46 02 70 "
    },
    {
        "IDWilaya": 27,
        "NomBureau": "MOSTAGANEM",
        "Reclamation": "06 76 73 07 94"
    },
    {
        "IDWilaya": 28,
        "NomBureau": "MSILA",
        "Reclamation": "07 70 82 41 31 "
    },
    {
        "IDWilaya": 28,
        "NomBureau": "BOUSAADA",
        "Reclamation": "0770 19 11 46"
    },
    {
        "IDWilaya": 29,
        "NomBureau": "MASCARA",
        "Reclamation": "07 72 03 23 02"
    },
    {
        "IDWilaya": 30,
        "NomBureau": "OUARGLA",
        "Reclamation": "07 70 61 21 03"
    },
    {
        "IDWilaya": 30,
        "NomBureau": "HASSI MESSAOUD",
        "Reclamation": "07 70 55 88 88"
    },
    {
        "IDWilaya": 31,
        "NomBureau": "ORAN - EL-MORCHID",
        "Reclamation": ""
    },
    {
        "IDWilaya": 31,
        "NomBureau": "ORAN - MILLENIUM ",
        "Reclamation": ""
    },
    {
        "IDWilaya": 31,
        "NomBureau": "ORAN - MARAVAL",
        "Reclamation": "0770606524/  07707710890"
    },
    {
        "IDWilaya": 32,
        "NomBureau": "EL BAYADH",
        "Reclamation": "07 73 03 81 76 "
    },
    {
        "IDWilaya": 34,
        "NomBureau": "BORDJ BOU-ARRERIDJ",
        "Reclamation": "07 70 27 23 17"
    },
    {
        "IDWilaya": 35,
        "NomBureau": "BOUMERDES",
        "Reclamation": "07 83 39 56 68 "
    },
    {
        "IDWilaya": 35,
        "NomBureau": "BORDJ MENAIEL",
        "Reclamation": "05 53 16 17 89"
    },
    {
        "IDWilaya": 36,
        "NomBureau": "EL TARF",
        "Reclamation": "07 70 61 27 04"
    },
    {
        "IDWilaya": 38,
        "NomBureau": "TISSEMSILT",
        "Reclamation": "0770798051"
    },
    {
        "IDWilaya": 39,
        "NomBureau": "EL OUED",
        "Reclamation": "06 60 97 70 78"
    },
    {
        "IDWilaya": 40,
        "NomBureau": "KHENCHLA",
        "Reclamation": "06 57 98 93 65"
    },
    {
        "IDWilaya": 41,
        "NomBureau": "SOUK AHRAS",
        "Reclamation": "07 95 94 98 08"
    },
    {
        "IDWilaya": 42,
        "NomBureau": "TIPAZA",
        "Reclamation": "07 70 20 04 60"
    },
    {
        "IDWilaya": 42,
        "NomBureau": "TIPAZA KOLEA",
        "Reclamation": "05 51 20 05 46 "
    },
    {
        "IDWilaya": 43,
        "NomBureau": "MILA",
        "Reclamation": "06 59 52 53 82 "
    },
    {
        "IDWilaya": 44,
        "NomBureau": "AIN DEFLA",
        "Reclamation": "07 70 99 45 79 "
    },
    {
        "IDWilaya": 45,
        "NomBureau": "NAAMA",
        "Reclamation": "06 59 26 93 47 "
    },
    {
        "IDWilaya": 46,
        "NomBureau": "AIN TEMOUCHENT",
        "Reclamation": "07 70 54 88 78"
    },
    {
        "IDWilaya": 47,
        "NomBureau": "GHARDIA",
        "Reclamation": "07 74 72 81 01"
    },
    {
        "IDWilaya": 48,
        "NomBureau": "RELIZANEZ",
        "Reclamation": "07 70 96 40 59"
    },
    {
        "IDWilaya": 51,
        "NomBureau": "OULED DJELLAL",
        "Reclamation": " 07 70 01 63 08"
    },
    {
        "IDWilaya": 52,
        "NomBureau": "BENI ABBES CITE EL MOUSTAKBEL",
        "Reclamation": "0662 56 67 02"
    },
    {
        "IDWilaya": 55,
        "NomBureau": "TOUGGOURT",
        "Reclamation": "07 95 81 58 86"
    }
]